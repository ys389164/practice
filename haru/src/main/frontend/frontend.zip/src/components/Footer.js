import React from 'react';
import home from '../assets/imgs/home.png';
import diary from '../assets/imgs/diary.png';
import memo from '../assets/imgs/memo.png';
import calendar from '../assets/imgs/canlendar.png';
import dDay from '../assets/imgs/d-day.png';

export default function Footer() {
    return (
        <footer className="footer">
            <ul className="footer__list">
                <li className="diaryTab">
                    <a href="#">
                        <img src={diary} alt="일기"/>
                    </a>
                </li>
                <li className="memoTab">
                    <a href="#">
                        <img src={memo} alt=""/>
                    </a>
                </li>
                <li className="mainTab">
                    <a href="#">
                        <img src={home} alt=""/>
                    </a>
                </li>
                <li className="calendarTab">
                    <a href="#">
                        <img src={calendar} alt=""/>
                    </a>
                </li>
                <li className="DdayTab">
                    <a href="#">
                        <img src={dDay} alt=""/>
                    </a>
                </li>
            </ul>
        </footer>
    )
}