import React from "react";
import logo from "../assets/imgs/logo.png";

export default function Header() {
    return (
        <header className="header" id="header">
            <h1 className="logo" id="logo">
                <a href="#">
                    {/* header */}
                    <img src={logo} alt="로고이미지" />
                </a>
            </h1>

            <div className="goSettingBtnWrap">
                <button type="button" className="settingBtn" id="settingBtn">Setting</button>
            </div>
        </header>)
}